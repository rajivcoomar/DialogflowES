package test;

import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;

import com.fasterxml.jackson.databind.ObjectMapper;

public class ZiptoIntentPhrases {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String folderPath = "C:\\Users\\Rajiv\\Videos\\DialogflowES\\ExtractTrainingPhrases\\Riu-Kris\\intents";
		String OutfolderPath = "C:\\Users\\Rajiv\\Videos\\DialogflowES\\ExtractTrainingPhrases\\Output";

		final File folder = new File(folderPath);
		ZiptoIntentPhrases test = new ZiptoIntentPhrases();
		ArrayList<String> listOfFiles = test.listFilesForFolder(folder);
		
		
		ObjectMapper om = new ObjectMapper();
		
		
		
		for(String fileName : listOfFiles) {
			
			String onlyFileName = fileName.substring(0,fileName.indexOf("_"));
			String testString = onlyFileName.toLowerCase();
			System.out.println(onlyFileName);
			
			
			try {
				UserSay[] root = om.readValue(new File(folderPath+"\\"+fileName), UserSay[].class);
				FileWriter myWriter = new FileWriter(OutfolderPath+"\\"+onlyFileName+"~.txt");
				int count = 1;
				for (UserSay itr : root) {
					String utterance = "";
					for(Datum values : itr.getData())
					{
						utterance = utterance  + values.getText();
					}
					
					if(count == root.length)
					{
						myWriter.write(utterance);
					}
					else
					{
						myWriter.write(utterance + "\n");
					}
					
					count++;
							
				}
				
			    myWriter.close();
			    System.out.println("completed");
			}  catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}
	
	public ArrayList<String> listFilesForFolder(final File folder) {
		ArrayList<String> listOfFiles = new ArrayList<String>();
	    for (final File fileEntry : folder.listFiles()) {
	        if (fileEntry.isDirectory()) {
	            listFilesForFolder(fileEntry);
	        } else {
	        	if(fileEntry.getName().contains("usersays_en"))
	        		listOfFiles.add(fileEntry.getName());
	        }
	    }
	    return listOfFiles;
	}

}
